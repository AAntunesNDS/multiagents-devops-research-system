aws_region                 = "us-east-1"
project_name               = "agentes-devops"
environment                = "prod"
vpc_cidr                   = "10.30.0.0/16"
azs                        = ["us-east-1a", "us-east-1b", "us-east-1c"]
single_nat_gateway         = false  # prod: 1 NAT por AZ (HA) -> ~US$ 99/mes
enable_interface_endpoints = true   # prod: reduz data processing do NAT
github_repository          = "seu-usuario/agentes-devops-iac"

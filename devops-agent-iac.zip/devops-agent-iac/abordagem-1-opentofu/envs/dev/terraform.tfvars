aws_region                 = "us-east-1"
project_name               = "agentes-devops"
environment                = "dev"
vpc_cidr                   = "10.20.0.0/16"
azs                        = ["us-east-1a", "us-east-1b"]
single_nat_gateway         = true   # dev: 1 NAT (~US$ 33/mes)
enable_interface_endpoints = false  # dev: desligado (cada endpoint ~US$ 7,30/mes/AZ)
github_repository          = "seu-usuario/agentes-devops-iac"
